CHANGELOG
=========

V 1.0.0
-------
 - Initial release

 V 1.0.1
-------
 - Bug fix